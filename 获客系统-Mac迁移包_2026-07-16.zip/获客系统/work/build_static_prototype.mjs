import fs from "node:fs";
import path from "node:path";

const root = process.cwd();
const source = fs.readFileSync(path.join(root, "app", "page.tsx"), "utf8");
const css = fs.readFileSync(path.join(root, "app", "globals.css"), "utf8")
  .replace('@import "tailwindcss";', "");

function extractArray(startMarker, endMarker) {
  const startBlock = source.indexOf(startMarker);
  if (startBlock < 0) throw new Error(`Missing ${startMarker}`);
  const arrayStart = source.indexOf("[", source.indexOf("=", startBlock));
  const arrayEnd = source.indexOf(endMarker, arrayStart);
  if (arrayStart < 0 || arrayEnd < 0) throw new Error(`Could not extract ${startMarker}`);
  const literal = source.slice(arrayStart, arrayEnd + 1);
  return Function(`"use strict"; return (${literal});`)();
}

const channels = extractArray("const channels:", "];\n\nconst customers");
const customers = extractArray("const customers:", "];\n\nconst channelMap");
const safeData = JSON.stringify({ channels, customers }).replaceAll("<", "\\u003c");

const html = `<!doctype html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Acquire OS｜全球B2B获客系统</title>
<meta name="description" content="门锁出海工厂全渠道客户情报系统演示版">
<style>
${css}
.static-hidden{display:none!important}.static-channel-tabs{display:grid;grid-template-columns:repeat(9,minmax(0,1fr));gap:5px}.detail-drawer{padding-bottom:20px}
@media(max-width:1280px){.static-channel-tabs{grid-template-columns:repeat(5,minmax(0,1fr))}}@media(max-width:900px){.static-channel-tabs{grid-template-columns:repeat(3,minmax(0,1fr))}}@media(max-width:620px){.static-channel-tabs{grid-template-columns:repeat(2,minmax(0,1fr))}}
</style>
</head>
<body>
<main class="app-shell">
  <aside class="sidebar">
    <div class="brand-block"><div class="brand-mark">A</div><div><strong>Acquire OS</strong><span>全球客户情报系统</span></div></div>
    <nav class="primary-nav" aria-label="主导航">
      <button class="nav-item active"><span>⌂</span>获客中心</button><button class="nav-item"><span>◎</span>账户雷达</button><button class="nav-item"><span>◇</span>联系人</button><button class="nav-item"><span>✓</span>任务与商机</button><button class="nav-item"><span>▦</span>数据源中心</button><button class="nav-item"><span>◫</span>分析中心</button>
    </nav>
    <div class="sidebar-foot"><div class="sync-status"><span class="status-dot"></span>8个渠道正常同步</div><div class="user-row"><span class="avatar">陈</span><div><strong>陈睿</strong><small>北美品牌客户组</small></div></div></div>
  </aside>
  <section class="workspace">
    <header class="topbar"><div><div class="eyebrow">获客中心 / 全渠道客户池</div><h1>全球目标客户</h1><p>从采购证据、决策人、项目与主动意向中识别最值得跟进的账户。</p></div><div class="top-actions"><span class="demo-badge">演示数据</span><button class="secondary-btn">导入数据</button><button class="primary-btn">＋ 新建名单</button></div></header>
    <section class="metrics" aria-label="客户池概览"><article><span>统一账户</span><strong>48,216</strong><small>本周新增 1,284</small></article><article><span>A / B级账户</span><strong>3,842</strong><small>关键联系人覆盖 72%</small></article><article><span>今日新信号</span><strong>176</strong><small>其中43条高优先级</small></article><article><span>待销售接手</span><strong>64</strong><small>12条将在今天逾期</small></article></section>
    <section class="channel-panel"><div class="static-channel-tabs" id="channel-tabs" role="tablist" aria-label="获客渠道"></div></section>
    <section class="content-panel">
      <div class="filterbar"><label class="search-box"><span>⌕</span><input id="query" aria-label="搜索客户" placeholder="搜索公司、联系人、产品或信号"></label><select id="region" aria-label="地区"><option>全部地区</option><option>北美</option><option>欧洲</option><option>中东</option><option>拉美</option><option>亚太</option><option>非洲</option></select><select id="grade" aria-label="账户等级"><option>全部等级</option><option>A</option><option>B</option><option>C</option></select><button class="filter-btn" id="clear-filters">清除筛选</button><div class="result-count" id="result-count"></div></div>
      <div class="table-wrap"><table><thead><tr><th>账户</th><th>客户类型 / 地区</th><th>渠道与关键信号</th><th>采购 / 项目价值</th><th>关键联系人</th><th>评分</th><th>阶段 / 负责人</th><th>更新时间</th></tr></thead><tbody id="customer-rows"></tbody></table><div class="empty-state static-hidden" id="empty-state"><strong>没有符合条件的客户</strong><span>尝试清除关键词或调整地区、等级筛选。</span></div></div>
    </section>
  </section>
  <div class="drawer-layer static-hidden" id="drawer-layer"><aside class="detail-drawer" role="dialog" aria-modal="true" aria-label="客户详情" id="detail-drawer"></aside></div>
</main>
<script>window.__ACQUIRE_DATA__=${safeData};</script>
<script>
(() => {
  const {channels, customers} = window.__ACQUIRE_DATA__;
  const channelMap = Object.fromEntries(channels.map(c => [c.id, c]));
  let activeChannel = 'all';
  const tabs = document.getElementById('channel-tabs');
  const rows = document.getElementById('customer-rows');
  const query = document.getElementById('query');
  const region = document.getElementById('region');
  const grade = document.getElementById('grade');
  const resultCount = document.getElementById('result-count');
  const emptyState = document.getElementById('empty-state');
  const layer = document.getElementById('drawer-layer');
  const drawer = document.getElementById('detail-drawer');
  const esc = value => String(value ?? '').replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
  const count = id => id === 'all' ? customers.length : customers.filter(c => c.channel === id).length;
  const scoreTone = score => score >= 80 ? 'strong' : score >= 65 ? 'medium' : 'light';
  function renderTabs(){tabs.innerHTML=channels.map(c => '<button role="tab" aria-selected="'+(activeChannel===c.id)+'" class="channel-tab '+(activeChannel===c.id?'selected':'')+'" data-channel="'+c.id+'"><span class="channel-symbol">'+esc(c.short)+'</span><span><strong>'+esc(c.label)+'</strong><small>'+esc(c.note)+'</small></span><em>'+count(c.id)+'</em></button>').join('');tabs.querySelectorAll('[data-channel]').forEach(btn=>btn.addEventListener('click',()=>{activeChannel=btn.dataset.channel;renderTabs();renderRows();}));}
  function filtered(){const q=query.value.trim().toLowerCase();return customers.filter(c=>(activeChannel==='all'||c.channel===activeChannel)&&(region.value==='全部地区'||c.region===region.value)&&(grade.value==='全部等级'||c.grade===grade.value)&&(!q||[c.company,c.legalName,c.country,c.type,c.contactName,c.keySignal,c.tags.join(' ')].join(' ').toLowerCase().includes(q)));}
  function renderRows(){const list=filtered();resultCount.innerHTML='<strong>'+list.length+'</strong> 条客户 · '+esc(channelMap[activeChannel].note);emptyState.classList.toggle('static-hidden',list.length!==0);rows.innerHTML=list.map(c=>'<tr data-id="'+c.id+'"><td><div class="account-main"><span class="company-logo">'+esc(c.company.slice(0,2).toUpperCase())+'</span><div><strong>'+esc(c.company)+'</strong><small>'+esc(c.legalName)+'</small><div class="tag-line">'+c.tags.slice(0,2).map(t=>'<span>'+esc(t)+'</span>').join('')+'</div></div></div></td><td><strong>'+esc(c.type)+'</strong><small>'+esc(c.country)+' · '+esc(c.city)+'</small><small>'+esc(c.employees)+'人</small></td><td><span class="channel-pill">'+esc(channelMap[c.channel].label)+'</span><strong class="signal-text">'+esc(c.keySignal)+'</strong><small>'+esc(c.source)+'</small></td><td><strong>'+esc(c.estimatedValue)+'</strong><small>'+esc(c.buyingEvidence)+'</small><small>趋势：'+esc(c.purchaseTrend)+'</small></td><td><strong>'+esc(c.contactName)+'</strong><small>'+esc(c.contactTitle)+'</small><small>'+esc(c.contactVerified)+'</small></td><td><div class="score score-'+scoreTone(c.score)+'">'+c.score+'</div><small>'+esc(c.confidence)+'</small></td><td><span class="grade grade-'+c.grade+'">'+c.grade+'级</span><strong>'+esc(c.stage)+'</strong><small>'+esc(c.owner)+'</small></td><td><strong>'+esc(c.updated)+'</strong><small>'+esc(c.freshness)+'</small><small>'+esc(c.sourceId)+'</small></td></tr>').join('');rows.querySelectorAll('[data-id]').forEach(row=>row.addEventListener('click',()=>openDetail(customers.find(c=>c.id===row.dataset.id))));}
  const info=(label,value)=>'<div class="info-item"><span>'+esc(label)+'</span><strong>'+esc(value)+'</strong></div>';
  function openDetail(c){if(!c)return;drawer.innerHTML='<div class="drawer-head"><div class="detail-identity"><span class="detail-logo">'+esc(c.company.slice(0,2).toUpperCase())+'</span><div><div class="detail-title-row"><h2>'+esc(c.company)+'</h2><span class="grade grade-'+c.grade+'">'+c.grade+'级账户</span></div><p>'+esc(c.legalName)+'</p><div class="detail-meta"><span>'+esc(c.country)+' · '+esc(c.city)+'</span><span>'+esc(c.type)+'</span><span>'+esc(c.employees)+'人</span></div></div></div><button class="close-btn" id="close-drawer" aria-label="关闭详情">×</button></div><div class="decision-card"><div><span>账户评分</span><strong>'+c.score+'</strong></div><div class="decision-copy"><span>为什么现在值得跟进</span><strong>'+esc(c.keySignal)+'</strong><small>置信度 '+esc(c.confidence)+' · 数据新鲜度 '+esc(c.freshness)+'</small></div></div><div class="drawer-actions"><button class="primary-btn">创建跟进任务</button><button class="secondary-btn">加入客户名单</button><button class="secondary-btn">反馈数据问题</button></div>'+section('企业画像','标准账户 · '+c.id,[info('官方网站',c.website),info('成立年份',c.founded),info('估算营收',c.revenue),info('企业规模',c.scale+' · '+c.employees+'人'),info('主要产品',c.products.join('、')),info('认证 / 要求',c.certifications.join('、'))].join(''))+section(channelMap[c.channel].label+'专属信息',c.source,'<div class="info-grid channel-info">'+c.channelFields.map(x=>info(x[0],x[1])).join('')+'</div><div class="evidence-box"><span>渠道证据</span><p>'+esc(c.channelEvidence)+'</p></div>',true)+section('采购与供应商情报','证据可追溯',[info('购买证据',c.buyingEvidence),info('最近采购 / 节点',c.lastPurchase),info('采购趋势',c.purchaseTrend),info('预估机会价值',c.estimatedValue),info('HS / 产品编码',c.hsCodes.join('、')),info('当前供应商',c.currentSuppliers.join('；'))].join(''))+contactSection(c)+actionSection(c)+section('数据来源与合规',c.sourceId,[info('数据来源',c.source),info('来源说明',c.sourceUrl),info('最近更新',c.updated+' · '+c.freshness),info('可信度',c.confidence)].join('')+'<div class="compliance-note"><strong>合规提示</strong><span>'+esc(c.compliance)+'</span></div>');layer.classList.remove('static-hidden');document.body.style.overflow='hidden';document.getElementById('close-drawer').addEventListener('click',closeDetail);}
  function section(title,meta,body,raw=false){return '<section class="detail-section"><div class="section-title"><h3>'+esc(title)+'</h3><span>'+esc(meta)+'</span></div>'+(raw?body:'<div class="info-grid">'+body+'</div>')+'</section>';}
  function contactSection(c){return '<section class="detail-section"><div class="section-title"><h3>关键联系人</h3><span>'+esc(c.contactRole)+'</span></div><div class="contact-card"><div class="contact-avatar">'+esc(c.contactName==='待补全'?'?':c.contactName.slice(0,1))+'</div><div class="contact-copy"><strong>'+esc(c.contactName)+'</strong><span>'+esc(c.contactTitle)+'</span><small>'+esc(c.contactVerified)+'</small></div><div class="contact-detail"><span>'+esc(c.contactEmail)+'</span><span>'+esc(c.contactPhone)+'</span><span>'+esc(c.contactLinkedIn)+'</span><span>语言：'+esc(c.language)+'</span></div></div></section>';}
  function actionSection(c){return '<section class="detail-section"><div class="section-title"><h3>销售行动</h3><span>'+esc(c.stage)+'</span></div><div class="next-action"><span>建议下一步</span><strong>'+esc(c.nextAction)+'</strong><small>计划时间：'+esc(c.nextActionDate)+' · 负责人：'+esc(c.owner)+'</small></div><div class="activity-row"><span>最近活动</span><strong>'+esc(c.lastActivity)+'</strong></div></section>';}
  function closeDetail(){layer.classList.add('static-hidden');document.body.style.overflow='';}
  layer.addEventListener('mousedown',e=>{if(e.target===layer)closeDetail();});document.addEventListener('keydown',e=>{if(e.key==='Escape')closeDetail();});[query,region,grade].forEach(el=>el.addEventListener('input',renderRows));document.getElementById('clear-filters').addEventListener('click',()=>{query.value='';region.value='全部地区';grade.value='全部等级';renderRows();});
  renderTabs();renderRows();
})();
</script>
</body>
</html>`;

const output = path.join(root, "outputs", "acquire-os-prototype.html");
fs.mkdirSync(path.dirname(output), { recursive: true });
fs.writeFileSync(output, html, "utf8");
console.log(output);
