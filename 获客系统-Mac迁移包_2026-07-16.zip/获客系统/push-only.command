#!/bin/bash
# Wonly Acquire OS — Push to GitHub only (no crawl), deploys the site fast.
# repo:   chloe19980401/businesswonly  (branch main)
# domain: business.foreverdoodle.com  (GitHub Pages)
# Double-click this file in Finder, or run:  bash push-only.command
cd "$(dirname "$0")"

echo "============================================================"
echo "  Push to GitHub only (NO crawl) - deploys the site fast"
echo "  repo:   chloe19980401/businesswonly  (branch main)"
echo "  domain: business.foreverdoodle.com"
echo "  folder: $(pwd)"
echo "============================================================"
echo

git add -A
git commit -m "deploy: frontend update (leads library + synced analytics/contacts)" || \
  echo "  Nothing new to commit, or commit failed - will still try to push."
git push origin main
if [ $? -ne 0 ]; then
  echo
  echo "  git push FAILED. Most likely you are not signed in to GitHub on this Mac."
  echo "  Open GitHub Desktop (or run 'gh auth login'), sign in as chloe19980401, then run this again."
  read -n 1 -s -r -p "Press any key to close..."
  exit 1
fi
echo
echo "============================================================"
echo "  DONE - pushed to GitHub."
echo "  Wait 1-2 minutes, open business.foreverdoodle.com and press Cmd+Shift+R."
echo "============================================================"
read -n 1 -s -r -p "Press any key to close..."
