#!/bin/bash
# Wonly Acquire OS — deep crawl + push to GitHub + deploy domain (Mac version).
# Needs Node.js v22+ and npm. Double-click in Finder, or run:  bash run-and-deploy.command
cd "$(dirname "$0")"

echo "============================================================"
echo "  Wonly Acquire OS - deep crawl + push to GitHub + deploy"
echo "  repo:   chloe19980401/businesswonly  (branch main)"
echo "  domain: business.foreverdoodle.com  (GitHub Pages)"
echo "  folder: $(pwd)"
echo "============================================================"
echo

echo "[1/5] Checking Node.js (need v22+)..."
if ! command -v node >/dev/null 2>&1; then
  echo "  Node.js not found. Install Node 22+ first: https://nodejs.org  (or: brew install node@22)"
  read -n 1 -s -r -p "Press any key to close..."; exit 1
fi
node -v
echo

echo "[2/5] Installing dependencies..."
npm install || { echo "  npm install failed."; read -n 1 -s -r -p "Press any key to close..."; exit 1; }
echo

echo "[3/5] Downloading headless Chromium (first run only)..."
npx playwright install chromium
echo

echo "[4/5] Running the deep crawler (may take minutes; some portals time out - normal)..."
npm run crawl
echo

echo "[5/5] Commit and push to GitHub..."
git add -A
git commit -m "update: deep crawler + frontend refresh"
git push origin main || { echo "  git push failed - sign in to GitHub on this Mac, then rerun."; read -n 1 -s -r -p "Press any key to close..."; exit 1; }
echo
echo "============================================================"
echo "  DONE. business.foreverdoodle.com updates in ~1-2 minutes."
echo "  Open the site and press Cmd+Shift+R to bypass cache."
echo "============================================================"
read -n 1 -s -r -p "Press any key to close..."
