# Wonly 获客系统 · 迁移到 Mac 说明

这是项目的完整快照（已排除可自动重建的 `node_modules`、`dist`、缓存），包含最新的线索数据（`crawler/leads.json` 现 **2229 条 / 59 国**）、前端 `index.html`、全部源码与配置、`outputs/` 交付物，以及本迁移指南和 Mac 版部署脚本。

线上站点本质上就是 GitHub Pages 托管的 `index.html`（域名 `business.foreverdoodle.com`），部署方式 = `git push` 到仓库 `chloe19980401/businesswonly` 的 `main` 分支。`vinext`/Next/Cloudflare 那套是开发脚手架，日常更新线索只需改文件 + push。

---

## 一、Mac 上装好基础环境（一次性）

1. **Node.js 22+**：去 https://nodejs.org 下载 LTS，或用 Homebrew：
   ```bash
   brew install node@22
   ```
2. **Git**：Mac 一般自带；没有就装 [GitHub Desktop for Mac](https://desktop.github.com/) 并用账号 `chloe19980401` 登录（用来推送）。
   命令行方式可用 `gh auth login` 或配置 SSH/HTTPS 凭据。

## 二、放置项目（二选一）

**方式 A（推荐，保留 git 历史）**
```bash
git clone https://github.com/chloe19980401/businesswonly.git
```
然后把本压缩包里的文件**覆盖**到 clone 出来的文件夹（把本包内容整体拷进去，覆盖同名文件），
这样既有完整 git 历史与远程配置，又带上了本快照里可能尚未 push 的最新线索数据。

**方式 B（直接用本快照）**
直接把本文件夹放到你想要的位置，然后初始化 git 并接上远程：
```bash
cd 获客系统
git init
git add -A && git commit -m "import snapshot"
git branch -M main
git remote add origin https://github.com/chloe19980401/businesswonly.git
git push -u origin main --force   # 首次覆盖远程，请确认这是你要的
```
> 方式 B 会用本快照覆盖远程历史，仅在你确定以本快照为准时使用。多数情况建议方式 A。

## 三、安装依赖 & 本地开发（可选）
```bash
npm install
npm run dev      # 本地开发预览
npm run build    # 构建
```
> 首次跑爬虫需要 Chromium：`npx playwright install chromium`

## 四、日常部署（更新线索 → 上线）
改完 `crawler/leads.json` / `crawler/market.json` / `index.html` 后：
```bash
bash push-only.command
```
（或在 Finder 里给 `push-only.command` 加执行权限后双击）
push 成功后等 1–2 分钟，打开 `business.foreverdoodle.com`，按 **Cmd+Shift+R** 强制刷新。

首次让 `.command` 脚本可双击运行：
```bash
chmod +x push-only.command run-and-deploy.command
```

## 五、继续用 Cowork（Claude 桌面端）
在 Mac 装好 Claude 桌面 App 后，把这个项目文件夹连接给 Cowork，就能像之前一样让我直接改文件、挖线索、写回磁盘。

---

## 包内容说明
- `index.html` — 前端单页应用（登录 wonly / wonly123；客户线索库、市场调研、获客方式等）。
- `crawler/` — 数据：`leads.json`（2229 条线索）、`market.json`（21 国市场调研）、其余为配置/来源/历史数据。
- `outputs/` — 历次交付的 Excel/Word 背调表（`.gitignore` 默认忽略，本包特意带上）。
- `app/ worker/ db/ build/ public/ *.config.*` — vinext/Cloudflare 开发脚手架源码与配置。
- `skills/lead-research/` — 线索研究技能包。
- `push-only.command` / `run-and-deploy.command` — Mac 版部署脚本（对应原 Windows 的 `.bat`）。
- `CNAME` — 自定义域名 `business.foreverdoodle.com`（勿删）。

## 未包含（需重新生成或体积原因）
- `node_modules/`（跑 `npm install` 重建）
- `dist/` `.next/` `.wrangler/`（构建/缓存，自动生成）
- `crawler/runs/`（历史爬虫日志，非必需）
